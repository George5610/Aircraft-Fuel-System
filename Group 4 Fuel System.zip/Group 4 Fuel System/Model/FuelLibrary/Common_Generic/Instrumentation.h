/* Instrumentation.h - defines instrumentation interface */

#ifndef _INSTRUMENTATION_
#define _INSTRUMENTATION_

#include <stdio.h>

#ifndef inst_printf
#define inst_printf printf
#endif

#ifndef err_printf
#define err_printf  printf
#endif

#endif
