/*
 * OrifaceControlBlock.h
 *
 * Block for oriface control
 *
 */

extern double GetOrifaceRes(double flow,double c,double prevRes);
